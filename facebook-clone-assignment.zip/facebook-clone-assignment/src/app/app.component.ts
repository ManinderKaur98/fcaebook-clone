import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators ,ReactiveFormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
   _CreatePostForm: FormGroup;
  base64textString :any = [];
  PostedData : any = [];
  constructor(private toastr: ToastrService) { 
    this._CreatePostForm = new FormGroup({
      Image: new FormControl(''),
      Name: new FormControl('Singh'),
    });
}

ngOnInit(): void {

  }

  onUploadChange(evt: any) {
    const file = evt.target.files[0];
  
    if (file) {
      const reader = new FileReader();
  
      reader.onload = this.handleReaderLoaded.bind(this);
      reader.readAsBinaryString(file);
    }
  }
  
  handleReaderLoaded(e:any) {
    this.base64textString.push('data:image/png;base64,' + btoa(e.target.result));
  }
  


  get f() { return this._CreatePostForm.controls; }
            onSubmit() {
            var retrievedPostData = localStorage.getItem('PostData');
            if(retrievedPostData != null){
              this.PostedData = JSON.parse(retrievedPostData);
            }
            this._CreatePostForm.value.Image = this.base64textString[0];
            this.PostedData.push(this._CreatePostForm.value);
              
            console.log(this.PostedData);
            localStorage.setItem('PostData', JSON.stringify(this.PostedData));
            this.toastr.success('Successfully ', 'Post Added');
          }
}
